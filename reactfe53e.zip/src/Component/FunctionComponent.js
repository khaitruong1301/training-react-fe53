import React from 'react'

//React function component nội dung  hiển thị được chứa trong lệnh return của function này

export default function FunctionComponent() {

    //Nội dung component phải được chứa trong 1 thẻ bao phủ
    return (
        <div>
            <h1>React function Component 123</h1>
            <h3>Cybersoft frontend 53e</h3>
        </div>
    )
}
