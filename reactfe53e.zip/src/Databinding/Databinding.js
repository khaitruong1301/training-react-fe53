import React, { Component } from 'react'

export default class Databinding extends Component {
    render() {
        return (
            <div>
                123
            </div>
        )
    }
}
